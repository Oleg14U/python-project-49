import brain_games.game.prime
from brain_games.game_engine import play


def main():
    play(brain_games.game.prime)


if __name__ == '__main__':
    main()
