import brain_games.game.even
from brain_games.game_engine import play


def main():
    play(brain_games.game.even)


if __name__ == '__main__':
    main()
