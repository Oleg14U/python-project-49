# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.game', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Math and Logic games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Oleg14U/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Oleg14U/python-project-49/actions)\n<a href="https://codeclimate.com/github/Oleg14U/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/6f83138426e4c233b3cb/maintainability" /></a>\n\n[Описание]:\nПроект представляет с собой набор из пяти игр на логику.\nКалькулятор. Арифметические выражения, которые необходимо вычислить.\nПрогрессия. Поиск пропущенных чисел в последовательности чисел.\nОпределение четного числа.\nОпределение наибольшего общего делителя.\nОпределение простого числа.\n\n[Версия]:\nPython 3.8.10\nhexlet-code 0.1.0\n\n[Установка]:\nДля установки пакета из операционной системы, используйте команду python3 -m pip install --user dist/*.whl. Её необходимо запускать из корневой директории проекта.\npoetry install brain-games\n\n[Запуск]:\n[![asciicast](https://asciinema.org/a/BgMbSY4zl8El94LUX9iQkaXEX.svg)](https://asciinema.org/a/BgMbSY4zl8El94LUX9iQkaXEX) - команда: brain-even "Проверка на четность"\n[![asciicast](https://asciinema.org/a/ZOHoZ6XB4TTTxQCVBNzhOBOxV.svg)](https://asciinema.org/a/ZOHoZ6XB4TTTxQCVBNzhOBOxV) - команда: brain-calc "Дать ответ на математическое выражение"\n[![asciicast](https://asciinema.org/a/iiZY6d0sekA47Sw7cqiXLiEV2.svg)](https://asciinema.org/a/iiZY6d0sekA47Sw7cqiXLiEV2) - команда: brain-gcd "Вписать наибольший общий делитель"\n[![asciicast](https://asciinema.org/a/uHhnjBy8VrMryxRRrWjCVqULd.svg)](https://asciinema.org/a/uHhnjBy8VrMryxRRrWjCVqULd) - команда: brain-progression "Вставить в пропуск число, продолжающее арифметическую прогрессию"\n[![asciicast](https://asciinema.org/a/VJ8GQn58E69PTv7OLwpmbN8IO.svg)](https://asciinema.org/a/VJ8GQn58E69PTv7OLwpmbN8IO) - команда: brain-prime "Ответить - "простое-ли число?""\n',
    'author': 'Oleg14U ',
    'author_email': 'hohleghek@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Oleg14U/python-project-49/',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.10,<4.0.0',
}


setup(**setup_kwargs)
