import brain_games.game.gcd
from brain_games.game_engine import play


def main():
    play(brain_games.game.gcd)


if __name__ == '__main__':
    main()
