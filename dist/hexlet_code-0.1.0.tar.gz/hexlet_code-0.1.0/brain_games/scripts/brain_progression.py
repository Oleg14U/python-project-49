import brain_games.game.prog
from brain_games.game_engine import play


def main():
    play(brain_games.game.prog)


if __name__ == '__main__':
    main()
