### Hexlet tests and linter status:
[![Actions Status](https://github.com/Oleg14U/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Oleg14U/python-project-49/actions)
<a href="https://codeclimate.com/github/Oleg14U/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/6f83138426e4c233b3cb/maintainability" /></a>
https://asciinema.org/a/BgMbSY4zl8El94LUX9iQkaXEX
