### Hexlet tests and linter status:
[![Actions Status](https://github.com/Oleg14U/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Oleg14U/python-project-49/actions)
<a href="https://codeclimate.com/github/Oleg14U/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/6f83138426e4c233b3cb/maintainability" /></a>

[Установка]:
poetry install brain-games

[![asciicast](https://asciinema.org/a/BgMbSY4zl8El94LUX9iQkaXEX.svg)](https://asciinema.org/a/BgMbSY4zl8El94LUX9iQkaXEX) - brain-even "Проверка на четность"
[![asciicast](https://asciinema.org/a/ZOHoZ6XB4TTTxQCVBNzhOBOxV.svg)](https://asciinema.org/a/ZOHoZ6XB4TTTxQCVBNzhOBOxV) - brain-calc "Дать ответ на математическое выражение"
[![asciicast](https://asciinema.org/a/iiZY6d0sekA47Sw7cqiXLiEV2.svg)](https://asciinema.org/a/iiZY6d0sekA47Sw7cqiXLiEV2) - brain-gcd "Вписать наибольший общий делитель"
[![asciicast](https://asciinema.org/a/uHhnjBy8VrMryxRRrWjCVqULd.svg)](https://asciinema.org/a/uHhnjBy8VrMryxRRrWjCVqULd) - brain-progression "Вставить в пропуск число, продолжающее арифметическую прогрессию"
[![asciicast](https://asciinema.org/a/VJ8GQn58E69PTv7OLwpmbN8IO.svg)](https://asciinema.org/a/VJ8GQn58E69PTv7OLwpmbN8IO) - brain-prime "Ответить - "простое-ли число?""


